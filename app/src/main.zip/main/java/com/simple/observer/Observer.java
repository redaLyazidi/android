package com.simple.observer;

/**
 * Created by reda on 9/21/14.
 */
public interface Observer {

    void update();
}
